package com.project.ToDo.task;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaskService {

    @Autowired
    TaskRepository repo;

    public Task getTaskByID(long id) {
        Task t = repo.getReferenceById(id);
        return t;
    }

    public List<Task> getAllTasks() {
        List<Task> taskList = repo.findAll();
        return taskList;
    }
    //delete task before it's checked off. tie this to a button
    public void deleteTaskById(long id) {
        repo.deleteById(id);
    }

    //create/update task. tie this to button_click or press_enter
    public void saveTask(Task t) {
        repo.save(t);
    }

}
