package com.project.ToDo.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/task")
@Controller
public class TaskController {

    @Autowired
    private TaskService service;

    @GetMapping({"", "/home", "/", "task"})
    public String home() {
        return "home";
    }

    @GetMapping("/delete/id={goalId}")
    public String deleteTask(@PathVariable long ID, Model model) {
        service.deleteTaskById(ID);
        return "redirect:/task/home";
    }

    @PostMapping("/create")
    public String createTask(Task t) {
        service.saveTask(t);
        return "redirect:/task/home";
    }

    @PostMapping("/update/id={ID}")
    public String updateTask(@PathVariable long ID, Task t) {
        Task existing = service.getTaskByID(ID);
        existing.setName(t.getName());
        service.saveTask(existing);
        return "redirect:/task/home";
    }
}


